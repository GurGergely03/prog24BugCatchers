using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Palmmedia.ReportGenerator.Core.Common;

public class MultipleShields : MonoBehaviour
{
    public List<MyJson> alienJson = new List<MyJson>();
    public TextMeshPro tmp;
    public GameObject[] shields;
    public GameObject earth;
    public GameObject[] aliens;
    private GameObject[] selectedAliens;

    public List<string> _aliens;
    public List<string> alienNames;

    public float shieldDistance = 1.0f;
    public float moveSpeed = 5f;
    public float rotationSpeed = 5f;

    public int counter = 0;
    public float minShieldSeparation = 0.5f; // Minimum distance between shields

    void Start()
    {
        StreamReader sr = new StreamReader("C:\\Users\\M�rk\\Desktop\\8\\aliens.txt");
        while (!sr.EndOfStream)
        {
            _aliens.Add(sr.ReadLine());
        }
        sr.Close();

        foreach (string s in _aliens[0].Split(';'))
        {
            alienNames.Add(s);
        }

        //string json = File.ReadAllText("aliens_json.json");
        //alienJson = JsonSerializer..Deserialize<List<MyJson>>(json);


        counter++;

        selectedAliens = FindAliensByName(alienNames);

        StartedShields();
    }

    void Update()
    {

        if (Input.GetButtonDown("Fire1"))
        {
            alienNames.Clear();
            foreach (string s in _aliens[counter].Split(';'))
            {
                alienNames.Add(s);
            }
            counter++;
            selectedAliens = FindAliensByName(alienNames);
            if (counter == _aliens.Count) counter = 0;
        }

        MoveShields();
    }

    GameObject[] FindAliensByName(List<string> names)
    {
        List<GameObject> selected = new List<GameObject>();

        foreach (string name in names)
        {
            foreach (GameObject alien in aliens)
            {
                if (alien.name == name)
                {
                    selected.Add(alien);
                    
                }
            }
        }

        return selected.ToArray();
    }

    void StartedShields()
    {
        float radius = shieldDistance;

        for (int i = 0; i < shields.Length; i++)
        {
            float angle = i * Mathf.PI * 2f / shields.Length;

            float x = Mathf.Cos(angle) * radius;
            float z = Mathf.Sin(angle) * radius;
            float y = 0;
            shields[i].transform.position = new Vector3(x, y, z) + earth.transform.position;

            shields[i].transform.LookAt(earth.transform.position);

            Vector3 forward = shields[i].transform.forward;
            Vector3 upward = Vector3.up;

            Quaternion lookRotation = Quaternion.LookRotation(forward, upward);

            shields[i].transform.rotation = lookRotation * Quaternion.Euler(90f, 0f, 0f);
        }
    }

    void MoveShields()
    {
        for (int i = 0; i < shields.Length && i < selectedAliens.Length; i++)
        {
            GameObject alien = selectedAliens[i];

            Vector3 directionToAttacker = (alien.transform.position - earth.transform.position).normalized;

            Vector3 shieldPosition = earth.transform.position + directionToAttacker * shieldDistance;

            if (!IsShieldPositionOccupied(shieldPosition))
            {
                shields[i].transform.position = Vector3.Lerp(shields[i].transform.position, shieldPosition, Time.deltaTime * moveSpeed);

                Quaternion targetRotation = Quaternion.LookRotation(alien.transform.position - shields[i].transform.position);

                Quaternion adjustment = Quaternion.Euler(90, 0, 0);
                shields[i].transform.rotation = Quaternion.Slerp(shields[i].transform.rotation, targetRotation * adjustment, Time.deltaTime * rotationSpeed);
            }
        }
    }

    bool IsShieldPositionOccupied(Vector3 newPosition)
    {
        foreach (GameObject shield in shields)
        {
            if (Vector3.Distance(shield.transform.position, newPosition) < minShieldSeparation)
            {
                return true;
            }
        }
        return false;
    }
}
