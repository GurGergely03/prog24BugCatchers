using System.Collections;
using System.Collections.Generic;
public class MyJson
{

    public class Class1
    {
        public List<string> Aldebaran { get; set; }
        public List<string> Formalhaut { get; set; }
        public List<string> Vega { get; set; }
        public List<string> AlfaOrionis { get; set; }
        public List<string> Alioth { get; set; }
    }

}